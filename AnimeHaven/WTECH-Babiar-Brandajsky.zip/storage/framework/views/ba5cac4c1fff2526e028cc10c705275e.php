<section class="footer">
    <footer class="bg-body-tertiary">
        <div class="bg-dark">
            <div class="container p-4">
                
                <img class="footer-img" src="<?php echo e(asset('images/logo.png')); ?>" alt="" />

                
                <div class="row">
                    <div class="left-footer">
                        <ul class="list-unstyled mb-0">
                            <li>
                                <p>Copyright © AnimeHaven</p>
                            </li>
                            <li>
                                <p>
                                    Vytvorenie a dizajn stránky - Mário Babiar, Peter Brandajský
                                </p>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 mb-4 mb-md-0">
                        <ul class="list-unstyled">
                            <li>
                                <p>Tel. kontakt: 0910 638 409, 0902 203 124</p>
                            </li>
                            <li>
                                <p>Mail: xbabiar@stuba.sk, xbrandajsky@stuba.sk</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</section>


<script type="text/javascript">
    window.routes = {
        search: '<?php echo e(route('search')); ?>',
        productShowPattern: '<?php echo e(route('product.show', ['product_id' => ':id'])); ?>'
    };
</script>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>