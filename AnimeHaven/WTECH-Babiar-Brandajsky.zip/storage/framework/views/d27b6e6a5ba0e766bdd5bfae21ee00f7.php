<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="container-fluid navbar navbar-expand-md justify-content-center mt-1 products-nav">
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
            aria-label="Toggle navigation">
            Spresniť parametre
            <span class="navbar-toggler-icon"></span>
        </button>
        <form action="<?php echo e(route('product.index-search')); ?>" method="GET" class="navbar-collapse collapse row"
            id="navbarSupportedContent">
            <?php echo csrf_field(); ?>
            <?php if(request('sort')): ?>
                <input type="hidden" name="sort" value="<?php echo e(request('sort')); ?>">
            <?php endif; ?>
            
            <div class="filter-col-input-buttons">
                <div class="filter-row-input-buttons">
                    <label for="price">Cena:</label>
                    <label for="price_min">Od</label>
                    <input type="number" id="price_min" name="price_min" min="0"
                        value="<?php echo e(request('price_min') ?? 0); ?>" class="input-button-price" />
                    <label for="price_max">Do</label>
                    <input type="number" id="price_max" name="price_max" min="0"
                        value="<?php echo e(request('price_max') ?? 100); ?>" class="input-button-price" />
                </div>
            </div>
            
            <div class="filter-col-other">
                <select class="form-select filter-row-other" id="anime" name="anime">
                    <option value="" <?php echo e(request('anime') === '' ? 'selected' : ''); ?> hidden>Anime</option>
                    <option value="Naruto" <?php echo e(request('anime') === 'Naruto' ? 'selected' : ''); ?>>Naruto</option>
                    <option value="Bleach" <?php echo e(request('anime') === 'Bleach' ? 'selected' : ''); ?>>Bleach</option>
                    <option value="Death Note" <?php echo e(request('anime') === 'Death Note' ? 'selected' : ''); ?>>Death Note
                    </option>
                </select>
            </div>
            
            <div class="filter-col-other">
                <select class="form-select filter-row-other" id="color" name="color">
                    <option value="" <?php echo e(request('color') === '' ? 'selected' : ''); ?> hidden>Farba</option>
                    <option value="black" <?php echo e(request('color') === 'black' ? 'selected' : ''); ?>>Čierna</option>
                    <option value="white" <?php echo e(request('color') === 'white' ? 'selected' : ''); ?>>Biela</option>
                    <option value="blue" <?php echo e(request('color') === 'blue' ? 'selected' : ''); ?>>Modrá</option>
                </select>
            </div>
            
            <button type="submit" class="filter-col-btn filter-row-btn">Filtruj</button>
        </form>
    </div>

    
    <div class="container-fluid">
        <div class="row products-nav-2 mt-1 mb-1">
            <form method="GET" action="<?php echo e(route('product.index-search')); ?>" class="p-0">
                <?php echo csrf_field(); ?>
                <?php $__currentLoopData = request()->except('category', 'page', 'sort'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <input type="hidden" name="<?php echo e($name); ?>" value="<?php echo e($value); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <button type="submit" name="sort" value=""
                    class="button-order <?php echo e(request('sort') === null ? 'button-active' : ''); ?>">Top</button>
                <button type="submit" name="sort" value="price_asc"
                    class="button-order <?php echo e(request('sort') === 'price_asc' ? 'button-active' : ''); ?>">Najlacnejšie</button>
                <button type="submit" name="sort" value="price_desc"
                    class="button-order <?php echo e(request('sort') === 'price_desc' ? 'button-active' : ''); ?>">Najdrahšie</button>
            </form>
        </div>
    </div>

    
    <div class="row products container-fluid">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3 col-lg-4 col-md-6 col-6 mb-3">
                <div class="card">
                    <a href="<?php echo e(route('product.show', ['product_id' => $product->id])); ?>">
                        <img src="<?php echo e(asset(optional($product->images->first())->image)); ?>" class="card-img-top"
                            alt="..." />
                    </a>
                    <div class="card-body">
                        <h5 class="card-title">
                            <?php echo e($product->name); ?>

                        </h5>
                        <p class="card-text">Cena: <?php echo e($product->price); ?>€</p>
                        
                        
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <?php echo e($products->links('pagination::bootstrap-5')); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/product/index-search.blade.php ENDPATH**/ ?>