<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Main content -->
    <?php if (isset($component)) { $__componentOriginaldb85a96d2c5b36da592633b626706ee9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb85a96d2c5b36da592633b626706ee9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.profile-nav','data' => ['active' => 'orders']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('profile-nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('orders')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb85a96d2c5b36da592633b626706ee9)): ?>
<?php $attributes = $__attributesOriginaldb85a96d2c5b36da592633b626706ee9; ?>
<?php unset($__attributesOriginaldb85a96d2c5b36da592633b626706ee9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb85a96d2c5b36da592633b626706ee9)): ?>
<?php $component = $__componentOriginaldb85a96d2c5b36da592633b626706ee9; ?>
<?php unset($__componentOriginaldb85a96d2c5b36da592633b626706ee9); ?>
<?php endif; ?>
    <!-- Orders -->
    <div class="container-fluid user-profile-orders">
        <div class="row justify-content-center">
            <div>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mt-2">
                        <div class="card-header">
                            <h4>Objednávka č. <?php echo e($loop->iteration); ?></h4>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">Objednané produkty</h5>
                            <?php $__currentLoopData = $order->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="card-text"><?php echo e($variant->product->name); ?> - <?php echo e($variant->product->price); ?>€/ks -
                                    Počet kusov:
                                    <?php echo e($variant->pivot->amount); ?>

                                </p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <h5 class="card-title">Cena</h5>
                            <p class="card-text"><?php echo e($order->price); ?>€</p>
                            <h5 class="card-title">Dátum</h5>
                            <p class="card-text"><?php echo e($order->created_at->format('d.m.Y')); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/profile/orders.blade.php ENDPATH**/ ?>