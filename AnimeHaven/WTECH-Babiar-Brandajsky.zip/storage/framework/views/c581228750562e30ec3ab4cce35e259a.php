<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form action="<?php echo e(route('store-delivery-payment')); ?>" method="POST" class="p-0">
        <?php echo csrf_field(); ?>
        <section class="main-content content">
            <div class="delivery-payment-container">
                <div class="container-flex">
                    <h1>Doprava</h1>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="transportation" value="packeta_home"
                            id="packeta_home"
                            <?php echo e(old('transportation', session('transportation')) == 'packeta_home' ? 'checked' : ''); ?> />
                        <label class="form-check-label" for="packeta_home"> Doručenie Domov - Packeta Home </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="transportation" value="sps"
                            id="sps"
                            <?php echo e(old('transportation', session('transportation')) == 'sps' ? 'checked' : ''); ?> />
                        <label class="form-check-label" for="sps">
                            Doručenie Domov - SPS Slovak Parcel Service
                        </label>
                    </div>
                </div>
                <div class="container-flex mt-4">
                    <h1>Platba</h1>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="payment_method" value="card_payment"
                            id="card_payment"
                            <?php echo e(old('payment_method', session('payment_method')) == 'card_payment' ? 'checked' : ''); ?> />
                        <label class="form-check-label" for="card_payment"> Online Platba Kartou </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="payment_method" value="google_pay"
                            id="google_pay"
                            <?php echo e(old('payment_method', session('payment_method')) == 'google_pay' ? 'checked' : ''); ?> />
                        <label class="form-check-label" for="google_pay"> Google Pay </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="payment_method" value="cash_on_delivery"
                            id="cash_on_delivery"
                            <?php echo e(old('payment_method', session('payment_method')) == 'cash_on_delivery' ? 'checked' : ''); ?> />
                        <label class="form-check-label" for="cash_on_delivery"> Dobierkou na mieste </label>
                    </div>
                </div>
            </div>
            <div class="del-pay-buttons-container">
                <button id="del-pay-back-button" type="button" class="del-pay-back-button"
                    onclick="window.location.href='<?php echo e(route('cart.show')); ?>'">
                    Späť
                </button>
                <button type="submit" class="del-pay-next-button">
                    Ďalej
                </button>
            </div>
        </section>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/order/delivery-payment.blade.php ENDPATH**/ ?>