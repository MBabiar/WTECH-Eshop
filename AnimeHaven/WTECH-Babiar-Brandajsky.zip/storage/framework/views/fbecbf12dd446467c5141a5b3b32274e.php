<?php if(Auth::user() && Auth::user()->isAdmin()): ?>
    <a href="<?php echo e(route('product.create')); ?>" class="floating-button">Nový Produkt</a>
<?php endif; ?>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/layouts/partials/add-product.blade.php ENDPATH**/ ?>