<nav class="navbar navbar-expand-sm bg-primary" aria-label="Main-Navigation">
    <div class="container justify-content-end">
        
        <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavId"
            aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        
        <div class="collapse navbar-collapse justify-content-center" id="collapsibleNavId">
            <ul class="navbar-nav mt-2 mt-lg-0 list-group">
                <li class="list-group-item-start">
                    <a href="<?php echo e(route('product.index', ['category' => 'shirt'])); ?>"
                        class="nav-link-product-type">Tričká</a>
                </li>
                <li class="list-group-item-custom">
                    <a href="<?php echo e(route('product.index', ['category' => 'hoodie'])); ?>"
                        class="nav-link-product-type">Mikiny</a>
                </li>
                <li class="list-group-item-custom">
                    <a href="<?php echo e(route('product.index', ['category' => 'hat'])); ?>"
                        class="nav-link-product-type">Čiapky</a>
                </li>
            </ul>
        </div>
    </div>
</nav>


<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/layouts/partials/nav-bar.blade.php ENDPATH**/ ?>