<div class="container img-container">
    <a href="homepage.html">
        <img src="<?php echo e(asset('images/logo.png')); ?>" class="img-fluid" alt="" />
    </a>
</div>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/components/logo-image.blade.php ENDPATH**/ ?>