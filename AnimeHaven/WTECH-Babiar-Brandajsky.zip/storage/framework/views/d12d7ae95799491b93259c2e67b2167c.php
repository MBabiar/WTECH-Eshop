<div class="container-fluid user-profile-menu">
    <div class="row products-nav-2 mt-1 mb-1 justify-content-center">
        <button type="button" class="button-order <?php echo e($active == 'password' ? 'active' : ''); ?>"
            onclick="window.location.href='<?php echo e(route('password.change')); ?>'">
            Zmena hesla
        </button>
        <button type="button" class="button-order <?php echo e($active == 'orders' ? 'active' : ''); ?>"
            onclick="window.location.href='<?php echo e(route('orders')); ?>'">
            Moje objednávky
        </button>
    </div>
</div>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/components/profile-nav.blade.php ENDPATH**/ ?>