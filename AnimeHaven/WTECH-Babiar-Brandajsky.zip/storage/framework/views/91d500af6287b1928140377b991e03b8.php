<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    
    <div class="container mt-4">
        <h1 class="product-header-name"><?php echo e($product->name); ?></h1>
        <div class="row justify-content-center align-items-center">
            <div class="product-column-images">
                <div class="card">
                    <img class="card-img-top main-image" src="<?php echo e(asset(optional($product->images->first())->image)); ?>"
                        alt="Title" />
                </div>
                <div class="row-sub-images">
                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sub-image">
                            <div class="card">
                                <img src="<?php echo e(asset($image->image)); ?>" class="sub-image" alt="Title" />
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="product-column-details">
                <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                    <div class="container-flex mt-3">
                        <?php echo e($product->description); ?>

                    </div>
                    <br />
                    <div class="container-flex">
                        <div class="row">
                            <p class="col-12">Vyberte Veľkosť:</p>
                            <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->first): ?>
                                    <label class="product-size-button button-active">
                                        <input type="radio" name="size" id="size<?php echo e($variant->size); ?>"
                                            value="<?php echo e($variant->size); ?>" checked>
                                        <?php echo e($variant->size); ?>

                                    </label>
                                <?php else: ?>
                                    <label class="product-size-button">
                                        <input type="radio" name="size" id="size<?php echo e($variant->size); ?>"
                                            value="<?php echo e($variant->size); ?>">
                                        <?php echo e($variant->size); ?>

                                    </label>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <br />
                    <div class="container mb-3">
                        <p id="stock-display">
                            <?php if($variants->first()->stock <= 0): ?>
                                Nedostupné
                            <?php elseif($variants->first()->stock <= 5): ?>
                                Skladom (<?php echo e($variants->first()->stock); ?>ks)
                            <?php else: ?>
                                Skladom (&gt;5ks)
                            <?php endif; ?>
                        </p>
                        <div class="row">
                            <h1 class="col-product-price"><?php echo e($product->price); ?>€ /ks</h1>
                            <div class="col-piece-add-to-cart">
                                <div class="row-piece-input">
                                    <input type="number" id="amount" name="amount" class="input-piece-amount"
                                        value="1" min="1" data-min="1" required>
                                    </input>

                                    <div class="col">
                                        <div class="row">
                                            <button type="button" id="inc-button" class="inc-dec-button">↑</button>
                                        </div>
                                        <div class="row">
                                            <button type="button" id="dec-button" class="inc-dec-button">↓</button>
                                        </div>
                                    </div>
                                </div>

                                <button id="addToCartButton" type="submit" class="add-to-cart-btn">
                                    Pridať do košíka
                                </button>

                            </div>
                        </div>
                    </div>
                </form>

                
                <?php if(Auth::user() && Auth::user()->isAdmin()): ?>
                    <div class="container">
                        <div class="row justify-content-center">
                            <a class="admin-btn btn-warning" href="<?php echo e(route('product.edit', $product)); ?>">
                                Upraviť
                            </a>
                            <form id="admin-delete" action="<?php echo e(route('product.destroy', $product)); ?>" method="POST"
                                class="delete-product-form">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="admin-btn btn-danger">Vymazať</button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>

    
    <script type="text/javascript">
        window.productId = <?php echo json_encode($product->id, 15, 512) ?>;
    </script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/product/show.js']); ?>;
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/product/show.blade.php ENDPATH**/ ?>