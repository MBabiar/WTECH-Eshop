<nav class="navbar navbar-light bg-dark" aria-label="Main-Bar">
    <div class="container-fluid">
        
        <a href="<?php echo e(route('homepage')); ?>" class="main-logo">
            <img src="<?php echo e(asset('images/logo.png')); ?>" class="img-fluid" alt="" />
        </a>

        
        <form id="searchFormMain" class="main-search d-flex" method="GET" action="<?php echo e(route('product.index-search')); ?>">
            <?php echo csrf_field(); ?>
            <input id="searchInput" class="form-control me-2" type="query" name="query" placeholder="Vyhľadať"
                autocomplete="off" />
            <div id="searchResults" class="search-dropdown-menu"></div>
            <button class="btn btn-outline-success" type="submit">Hľadať</button>
        </form>

        
        <div class="prof-cart-link">
            
            <div class="col nav-link">
                <img src="<?php echo e(asset('images/profile_placeholder.png')); ?>" class="img-fluid profile-img" alt=""
                    data-bs-toggle="modal" data-bs-target="#ProfileModal" />
                <div class="modal fade" id="ProfileModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content dropdown-menu">
                            <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profil</a>
                            <?php if(Auth::check()): ?>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item">Odhlásiť sa</button>
                                </form>
                            <?php else: ?>
                                <a class="dropdown-item" href="<?php echo e(route('login')); ?>">Prihlásiť sa</a>
                                <a class="dropdown-item" href="<?php echo e(route('register')); ?>">Registrovať sa</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            
            
            <a href="<?php echo e(route('cart.show')); ?>" class="col nav-link">
                <img src="<?php echo e(asset('images/shopping_cart.png')); ?>" class="img-fluid" alt="" />
            </a>
        </div>
    </div>
</nav>
<?php /**PATH C:\Programming\FIIT-STU\Semester_4\WTECH\WTECH-Eshop\AnimeHaven\resources\views/layouts/partials/main-bar.blade.php ENDPATH**/ ?>