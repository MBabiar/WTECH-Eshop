import "bootstrap";

// Layout Scripts
import "./partials/main-search";
