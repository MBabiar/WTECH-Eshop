<x-app-layout>
    <img src="{{ asset('images/homepage_logo.png') }}" class="img-fluid bg-light" alt="Logo" />
</x-app-layout>
