<x-app-layout>
    <x-profile-nav :active="''"></x-profile-nav>
</x-app-layout>
